const app = require('./app');

app.listen(7777,()=>{

    console.log("App Server Listening at Port 7777")
});